const constants = {
    openWeatherMap: {
        BASE_URL: "https://api.openweathermap.org/data/2.5/weather?q=",
        SECRET_KEY: "605113a748b17d04b1b05787530520f5"
    }
}

module.exports = constants;